# SGE-AL-trabajo-academia
Trabajo de Sistemas de Gestion Empresarial sobre el uso de Business Central 365 y el lenguaje de programacion AL

### Autores
Marco Sanz

Adrián Martín

### Información
Este trabajo esta orientado y creado con el fin de aprender el uso del lenguaje de programacion AL al igual que las herramientas de desarrollo para Microsoft Business Central.

El trabajo consiste en la creacion de tablas, paginas, listas y otros recursos y funciones, los cuales pueden ser vistos en el archivo **TODO.md** 

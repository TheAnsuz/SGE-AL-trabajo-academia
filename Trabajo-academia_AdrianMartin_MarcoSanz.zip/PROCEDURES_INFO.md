### Procedures
1. Procedure en Profesores.Page.al que muestra mediante un mensaje el promedio de los salarios de todos los profesores.
2. Procedure en Horario.Table.al usado para calcular el tiempo total en minutos y ajustarlo a su campo correspondiente.
2. Procedure en Information.Codeunit.al usado para calcular y visualizar estudiantes segun su genero (dato y ver pagina).
